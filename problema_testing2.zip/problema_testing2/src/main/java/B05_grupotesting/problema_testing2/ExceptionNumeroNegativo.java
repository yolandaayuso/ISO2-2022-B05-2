package B05_grupotesting.problema_testing2;

public class ExceptionNumeroNegativo extends Exception{
	public ExceptionNumeroNegativo (String mensaje) {
		super (mensaje);
	}


}


