package B05_grupotesting.problema_testing2;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import junit.framework.*;


/**
 * @author Yolanda y Raul
 *
 */

public class testing_problema2Test{
	static int lado1=0;
	static int lado2=0;
	static int lado3=0;
	static String mensaje="";
	Triangulo trinagulo= new Triangulo(mensaje,lado1,lado2,lado3);

	@Test
    public void testEvaluarNoEsTriangulo() {
        System.out.println("evaluar \"No es un triángulo por introducir valores incorrectos para los lados\"");
        Triangulo instance = new Triangulo(mensaje,7, 5, 3);
        String expResult = "El valor de los lados introducido no es correcto, ya que el mayor lado debe ser menor a la suma de los otros lados";
        String result = instance.evaluarTriangulo(3,4,10);
        assertEquals(expResult, result);
    }
	
	
	@Test
	public void testGetLado1() {
		System.out.println("evaluar \"Get lado1");
		int lado = 2;
			Triangulo triangulo = new Triangulo(mensaje,lado,2,3); 
			assertEquals(triangulo.getLado1(),lado);
		
	}
	@Test
	public void testGetLado2() {
		System.out.println("evaluar \"Get lado2");
		int lado = 2;
			Triangulo triangulo = new Triangulo(mensaje,2,lado,3); 
			assertEquals(triangulo.getLado2(),lado);
		
	}
	@Test
	public void testGetLado3() {
		System.out.println("evaluar \"Get lado3");
		int lado = 3;
		
		
			Triangulo triangulo = new Triangulo(mensaje,2,2,lado); 
			assertEquals(triangulo.getLado3(),lado);
		
	}

	@Test
    public void testEvaluarNoEsTrianguloNegativos() {
        System.out.println("evaluar \"No es un triángulo por introducir valores negativos\"");
        Triangulo instance = new Triangulo(mensaje,-7, -5, -3);
        String expResult = "El valor de los lados introducido no es correcto, ya que el mayor lado debe ser menor a la suma de los otros lados";
        String result = instance.evaluarTriangulo(3,4,10);
        assertEquals(expResult, result);
    }
	@Test
    public void testEvaluarNoEsTrianguloCeros() {
        System.out.println("evaluar \"No es un triángulo por introducir lados con 0\"");
        Triangulo instance = new Triangulo(mensaje,0, 0, 0);
        String expResult = "No es un triángulo válido";
        String result = instance.evaluarTriangulo(0,0,0);
        assertEquals(expResult, result);
    }
	@Test
    public void testEquilatero() {
        System.out.println("evaluar \"Trinagulo equilatero\"");
        Triangulo instance = new Triangulo(mensaje,3,3, 3);
        String expResult = "Es un triángulo equilatero y acutangulo";
        String result = instance.evaluarTriangulo(3,3,3);
        assertEquals(expResult, result);
       
    }
	@Test
    public void testEscaleno() {
        System.out.println("evaluar \"Trinagulo Escaleno\"");
        Triangulo instance = new Triangulo(mensaje,2,3, 4);
        String expResult = "Es un triángulo escaleno y obtuso";
        String result = instance.evaluarTriangulo(2,3,4);

        assertEquals(expResult, result);
       
    }
	@Test
    public void testIsosceles() {
        System.out.println("evaluar \"Trinagulo Isósceles\"");
        Triangulo instance = new Triangulo(mensaje,4,4, 6);
        String expResult = "Es un triángulo isosceles y obtuso";
        String result = instance.evaluarTriangulo(4,4,6);
        assertEquals(expResult, result);
       
    }
	@Test
    public void testRectangulo() {
        System.out.println("evaluar \"Trinagulo Escaleno y Rectangulo\"");
        
        Triangulo instance = new Triangulo(mensaje,4,3, 5);
        String expResult = "Es un triángulo escaleno y rectángulo";
        String result = instance.evaluarTriangulo(4,3,5);
        assertEquals(expResult, result);
       
    }
	@Test
    public void testObtuso() {
        System.out.println("evaluar \"Trinagulo Obtuso\"");
        Triangulo instance = new Triangulo(mensaje,4,2, 5);
        String expResult = "Es un triángulo escaleno y obtuso";
        String result = instance.evaluarTriangulo(4,2,5);
        assertEquals(expResult, result);
       
    }
	@Test
    public void testAcutangulo() {
        System.out.println("evaluar \"Trinagulo equilatero\"");
        Triangulo instance = new Triangulo(mensaje,4,4,4);
        String expResult = "Es un triángulo equilatero y acutangulo";
        String result = instance.evaluarTriangulo(4,4,4);
        assertEquals(expResult, result);
       
    }  
	
	@Test
	public void testSetlado1NoValido() {
		
		int lado1 = -4;
		
		try {
			Triangulo triangulo = new Triangulo(mensaje,0,0,0); 
			triangulo.setLado1(lado1);
		}catch (ExceptionNumeroNegativo ee) {
			assertEquals(ee.getMessage(),"No puedes introducir un número negativo.");
		}
	}
	@Test
	public void testSetlado1() {
		
		int lado1 = 4;
		
		try {
			Triangulo triangulo = new Triangulo(mensaje,0,0,0); 
			triangulo.setLado1(lado1);
		}catch (ExceptionNumeroNegativo ee) {
			fail("No debe saltar la excepcion, es un numero positivo.");
		}
	}
	@Test
	public void testSetlado2NoValido() {
		
		int lado2 = -4;
		
		try {
			Triangulo triangulo = new Triangulo(mensaje,0,0,0); 
			triangulo.setLado2(lado2);
		}catch (ExceptionNumeroNegativo ee) {
			assertEquals(ee.getMessage(),"No puedes introducir un número negativo.");
		}
	}
	@Test
	public void testSetlado3NoValido() {
		
		int lado3 = -4;
		
		try {
			Triangulo triangulo = new Triangulo(mensaje,0,0,0); 
			triangulo.setLado3(lado3);
		}catch (ExceptionNumeroNegativo ee) {
			assertEquals(ee.getMessage(),"No puedes introducir un número negativo.");
		}
	}
	@Test
	public void testSetlado3() {
		
		int lado3 = 4;
		
		try {
			Triangulo triangulo = new Triangulo(mensaje,0,0,0); 
			triangulo.setLado3(lado3);
		}catch (ExceptionNumeroNegativo ee) {
			fail("No debe saltar la excepcion, es un numero positivo.");
		}
	}
	@Test
	public void testSetlado2() {
		
		int lado2 = 4;
		
		try {
			Triangulo triangulo = new Triangulo(mensaje,0,0,0); 
			triangulo.setLado2(lado2);
		}catch (ExceptionNumeroNegativo ee) {
			fail("No debe saltar la excepcion, es un numero positivo.");
		}
	}
	
	
	
	
}
