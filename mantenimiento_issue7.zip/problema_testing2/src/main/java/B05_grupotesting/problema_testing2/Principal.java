
package B05_grupotesting.problema_testing2;

import java.util.Scanner;


/**
 * @author
 *
 */
public class Principal {
    /**
     * 
     */
    static Scanner teclado = new Scanner(System.in);
    /**
     * 
     */
    static final int lado1 = 7;
    /**
     * 
     */
    static final int lado2 = 5;
    /**
     * 
     */
    static final int lado3 = 3;

    /**
     * @param ar
     */
    public static void main(String[] ar) {
        Triangulo triangulo = new Triangulo("", lado1, lado2, lado3);
        System.out.println(triangulo.evaluarTriangulo(lado1, lado2, lado3));
    
    }
    
    protected Principal() {}
}
