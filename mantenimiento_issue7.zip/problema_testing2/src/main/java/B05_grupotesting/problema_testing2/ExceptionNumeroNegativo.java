
package B05_grupotesting.problema_testing2;

/**
 * @author 
 *
 */

public class ExceptionNumeroNegativo extends Exception {
    /**
     * @param mensaje
     */
    public ExceptionNumeroNegativo(String mensaje) {
        super(mensaje);
    }

}
